
import React from 'react';

export type View = 'home' | 'workshops' | 'masterclasses' | 'charla' | 'programa4w' | 'podcast' | 'privacy';

export interface SectionProps {
  title?: string;
  children: React.ReactNode;
  imageSrc: string;
  imageAlt: string;
  imageRight?: boolean;
  bgImage?: string;
  overlayOpacity?: string;
}

export interface CardProps {
  title: string;
  description: string;
  tag?: string;
  ctaText: string;
  onClick: () => void;
}
