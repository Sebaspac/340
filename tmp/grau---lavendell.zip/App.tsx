
import React, { useState, useEffect } from 'react';
import { View } from './types';
import { Navigation } from './components/Navigation';
import { Section } from './components/Section';
import { Testimonials } from './components/Testimonials';
import { PodcastSlider } from './components/ui/argent-loop-infinite-slider';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('home');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentView]);

  // --- COMPONENTE DE ESTRUCTURA DE SERVICIO (LOS 6 PASOS) ---
  const ServiceTemplate = ({ 
    hero, problem, transformation, clarification, authority, finalDecision 
  }: { 
    hero: { h1: string, sub: string, facts: string[], cta: string },
    problem: { title: string, content: string[], worldView: string, image: string },
    transformation: { title: string, imagination: string, shift: string, image: string },
    clarification: { notThis: string, perception: string, filter: string },
    authority: { narrative: string[] },
    finalDecision: { title: string, sub: string, cta: string }
  }) => (
    <div className="animate-in fade-in duration-1000 bg-[#F1F3F5] selection:bg-[#8FAEA3] selection:text-white">
      {/* 1. HERO EXISTENCIAL */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden px-8">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-[#F1F3F5] via-transparent to-[#F1F3F5] z-10"></div>
          <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920" className="w-full h-full object-cover opacity-10 grayscale fixed" alt="" />
        </div>
        <div className="relative z-20 max-w-[1100px] text-center space-y-16">
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-syne font-bold text-[#1C1C1E] tracking-tighter uppercase leading-[1.1] max-w-5xl mx-auto">
            {hero.h1}
          </h1>
          <p className="text-xl md:text-2xl text-[#1C1C1E]/60 font-serif-elegant italic max-w-3xl mx-auto leading-relaxed">
            {hero.sub}
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-left border-y border-[#1C1C1E]/10 py-12">
            {hero.facts.map((f, i) => (
              <div key={i}>
                <p className="text-[10px] text-[#A5A3B2] font-bold tracking-[0.3em] uppercase mb-1">Registro</p>
                <p className="text-[#1C1C1E] text-xs font-light uppercase tracking-widest">{f}</p>
              </div>
            ))}
            <div className="flex items-center justify-end col-span-2 md:col-span-1">
              <button className="bg-[#8FAEA3] text-white text-[10px] font-bold tracking-[0.4em] uppercase px-8 py-5 rounded-sm hover:bg-[#1C1C1E] transition-all">
                {hero.cta}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. PROBLEMA (RESONANCIA) */}
      <Section title={problem.title} imageSrc={problem.image} imageAlt="Resonancia" imageRight={false}>
        <div className="space-y-8">
          <div className="space-y-6 text-2xl font-light text-[#1C1C1E] leading-snug">
            {problem.content.map((p, i) => <p key={i}>{p}</p>)}
          </div>
          <p className="text-[#8FAEA3] font-serif-elegant italic text-2xl pt-8 border-t border-[#1C1C1E]/5">
            {problem.worldView}
          </p>
        </div>
      </Section>

      {/* 3. TRANSFORMACIÓN (MOGLICHKEITSRAUM) */}
      <Section title={transformation.title} imageSrc={transformation.image} imageAlt="Transformación" imageRight={true} bgImage="https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?auto=format&w=1920" overlayOpacity="bg-[#8FAEA3]/10">
        <div className="space-y-12">
          <p className="text-2xl text-[#1C1C1E] font-serif-elegant italic leading-relaxed">
            {transformation.imagination}
          </p>
          <div className="bg-white/40 backdrop-blur-md p-8 border-l-4 border-[#8FAEA3]">
            <p className="text-[#1C1C1E]/80 font-light text-lg">
              {transformation.shift}
            </p>
          </div>
        </div>
      </Section>

      {/* 4. CLARIFICACIÓN DE OFERTA (FILTRO) */}
      <section className="py-40 bg-white px-8 border-y border-[#1C1C1E]/5">
        <div className="max-w-4xl mx-auto text-center space-y-12">
          <span className="text-[#A5A3B2] font-bold tracking-[0.6em] text-[10px] uppercase">Lo que este espacio es (y lo que no)</span>
          <h2 className="text-3xl md:text-4xl font-syne font-bold text-[#1C1C1E] uppercase tracking-tighter">
            {clarification.notThis}
          </h2>
          <div className="grid md:grid-cols-2 gap-16 text-left pt-12">
            <div className="space-y-6">
              <p className="text-xl font-serif-elegant italic text-[#8FAEA3]">Percepción sobre Herramientas</p>
              <p className="text-[#1C1C1E]/70 font-light leading-relaxed">{clarification.perception}</p>
            </div>
            <div className="space-y-6">
              <p className="text-xl font-serif-elegant italic text-[#A5A3B2]">Efecto Filtro</p>
              <p className="text-[#1C1C1E]/70 font-light leading-relaxed">{clarification.filter}</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. AUTORIDAD NARRATIVA */}
      <section className="py-40 bg-[#1C1C1E] text-white px-8">
        <div className="max-w-[800px] mx-auto space-y-16 text-center">
          <span className="text-white/30 font-bold tracking-[0.5em] text-[10px] uppercase">La Coherencia de la Presencia</span>
          <div className="space-y-12 text-2xl md:text-3xl font-serif-elegant italic leading-relaxed opacity-90">
            {authority.narrative.map((p, i) => <p key={i}>{p}</p>)}
          </div>
          <div className="pt-8">
            <div className="w-16 h-px bg-[#8FAEA3] mx-auto"></div>
          </div>
        </div>
      </section>

      {/* 6. DECISIÓN FINAL */}
      <section className="py-48 bg-[#F1F3F5] px-8 text-center border-t border-[#1C1C1E]/5 relative overflow-hidden">
        <div className="max-w-4xl mx-auto space-y-12 relative z-10">
          <h2 className="text-4xl md:text-6xl font-syne font-bold text-[#1C1C1E] tracking-tighter uppercase leading-none">
            {finalDecision.title}
          </h2>
          <p className="text-xl md:text-2xl text-[#1C1C1E]/60 font-serif-elegant italic max-w-2xl mx-auto leading-relaxed">
            {finalDecision.sub}
          </p>
          <div className="pt-12">
            <button className="btn-liquid-glass bg-[#8FAEA3] text-white font-bold py-10 px-24 rounded-sm text-[12px] tracking-[0.5em] uppercase shadow-2xl">
              {finalDecision.cta}
            </button>
          </div>
          <p className="text-[10px] text-[#A5A3B2] uppercase tracking-[0.4em] font-bold pt-8">Invitación abierta · Sin presión externa</p>
        </div>
      </section>
      
      <Testimonials />
    </div>
  );

  const renderHome = () => (
    <div className="animate-in fade-in duration-1000 bg-[#F1F3F5] selection:bg-[#8FAEA3] selection:text-white">
      {/* HERO HOME */}
      <section className="h-screen relative flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920" className="w-full h-full object-cover opacity-20 fixed scale-105" alt="" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#F1F3F5] via-transparent to-[#F1F3F5]"></div>
        </div>
        <div className="relative z-10 text-center px-6 max-w-6xl">
          <span className="text-[#8FAEA3] font-syne font-bold text-[10px] tracking-[0.5em] uppercase mb-12 block">Orientación & Claridad</span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-syne font-bold text-[#1C1C1E] tracking-tighter uppercase leading-[1.1] mb-12">
            Un espacio para <br/><span className="text-[#8FAEA3]">reconectar</span> contigo
          </h1>
          <p className="text-xl md:text-3xl font-serif-elegant italic text-[#1C1C1E]/80 max-w-4xl mx-auto mb-16">
            Acompaño a personas sensibles a salir del piloto automático y habitar su propia verdad.
          </p>
          <div className="flex flex-col md:flex-row items-center justify-center gap-6">
            <button onClick={() => setCurrentView('charla')} className="btn-liquid-glass bg-[#8FAEA3] text-white font-bold py-6 px-12 text-[11px] tracking-[0.2em] uppercase">Charla gratuita</button>
            <button onClick={() => setCurrentView('workshops')} className="btn-liquid-glass border border-[#1C1C1E]/20 text-[#1C1C1E] font-bold py-6 px-12 text-[11px] tracking-[0.2em] uppercase">Explorar Talleres</button>
          </div>
        </div>
      </section>

      {/* RESONANCIA HOME */}
      <Section title="Este espacio es para ti si…" imageSrc="https://images.unsplash.com/photo-1518005020250-675f0f0fd13b?auto=format&w=800" imageAlt="Resonancia" imageRight={false}>
        <div className="grid grid-cols-1 gap-12 text-[#1C1C1E]">
          {["Vives un cambio interno que nadie más ve", "Sientes saturación pese a tener 'éxito'", "Has seguido el libreto pero algo no encaja", "Buscas cuestionar sin perder tu esencia"].map((text, i) => (
            <div key={i} className="flex items-start gap-6 group">
              <span className="text-[#A5A3B2] font-serif-elegant text-4xl opacity-40 group-hover:opacity-100 transition-opacity">0{i+1}</span>
              <p className="text-2xl font-light leading-snug pt-2">{text}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* CLARIFICACIÓN HOME (FORMATOS) */}
      <section className="py-40 bg-white px-8">
        <div className="max-w-[1400px] mx-auto">
          <div className="mb-24 space-y-4">
            <span className="text-[#A5A3B2] font-bold tracking-[0.5em] text-[10px] uppercase block opacity-80">Nuestra Oferta</span>
            <h2 className="text-4xl md:text-6xl font-syne font-bold text-[#1C1C1E] tracking-tighter uppercase leading-none">Formatos de Despertar</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: "Charla gratuita", subtitle: "Primer contacto", view: 'charla' as View },
              { title: "Webinar Intensivo", subtitle: "Conciencia y Claridad", view: 'masterclasses' as View },
              { title: "Workshop Presencial", subtitle: "Dirección y Acción", view: 'workshops' as View },
              { title: "Programa 4 Semanas", subtitle: "Transformación Real", view: 'programa4w' as View }
            ].map((item, i) => (
              <div key={i} onClick={() => setCurrentView(item.view)} className="p-12 bg-[#F1F3F5] border border-[#1C1C1E]/5 flex flex-col justify-between group cursor-pointer hover:bg-[#8FAEA3]/10 transition-all aspect-[3/4]">
                <div className="space-y-8">
                  <span className="text-[#A5A3B2] font-syne text-sm font-bold">0{i+1}</span>
                  <h3 className="text-3xl font-syne font-bold text-[#1C1C1E] uppercase leading-none group-hover:text-[#8FAEA3] transition-colors">{item.title}</h3>
                  <p className="text-[#8FAEA3] font-serif-elegant italic text-xl">{item.subtitle}</p>
                </div>
                <div className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#1C1C1E]/40 group-hover:text-[#8FAEA3]">Ver detalles</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Testimonials />
    </div>
  );

  return (
    <div className="min-h-screen">
      <Navigation currentView={currentView} setView={setCurrentView} />
      <main>
        {currentView === 'home' && renderHome()}
        
        {currentView === 'workshops' && (
          <ServiceTemplate 
            hero={{
              h1: "¿Es posible que la vida que sostienes con tanto esfuerzo no sea más que un guion que olvidaste cuestionar?",
              sub: "Tal vez lo que crees que es tu vida no es más que una repetición constante de lo que el mundo espera de ti.",
              facts: ["Ibiza / Madrid", "6 Horas", "Presencial", "Inmersión"],
              cta: "Habitar el Espacio"
            }}
            problem={{
              title: "La Vivencia",
              image: "https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&w=800",
              content: [
                "Haces. Logras. Repites. Pero el 'Yo' que hace todo eso se siente como un extraño.",
                "Sirves a la seguridad, pero has olvidado la libertad.",
                "Cumples roles: la experta, la pareja estable, la hija perfecta."
              ],
              worldView: "Crees que eres tus resultados. ¿Pero qué queda de ti cuando llega el silencio?",
            }}
            transformation={{
              title: "El Espacio",
              image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&w=800",
              imagination: "¿Y si dejas de buscar la respuesta en el exterior y permites que la visión emane de tu propia quietud?",
              shift: "No prometo éxito; prometo presencia radical. El cambio no es algo que haces, es algo que permites."
            }}
            clarification={{
              notThis: "No es una clase de gestión. Es un proceso de desidentificación.",
              perception: "Aquí no buscamos herramientas de productividad, sino la percepción que precede a cualquier acción.",
              filter: "Este espacio es para quienes ya no pueden seguir viviendo en piloto automático. Si buscas trucos rápidos, este no es tu lugar."
            }}
            authority={{
              narrative: [
                "Durante años fui la imagen perfecta del éxito externo.",
                "Hoy acompaño desde la coherencia de quien decidió dejar de actuar para una audiencia invisible."
              ]
            }}
            finalDecision={{
              title: "¿Deseas soltar el libreto?",
              sub: "Una invitación a descubrir quién eres cuando dejas de sostener tu personaje actual.",
              cta: "Aceptar Invitación"
            }}
          />
        )}

        {currentView === 'masterclasses' && (
          <ServiceTemplate 
            hero={{
              h1: "Buscas respuestas en la eficiencia, pero tal vez el silencio es lo único que realmente temes habitar.",
              sub: "Un análisis profundo sobre la ilusión del pensamiento continuo como motor de vida.",
              facts: ["Digital", "180 Minutos", "Inmediato", "Teoría & Praxis"],
              cta: "Entrar al Silencio"
            }}
            problem={{
              title: "La Ilusión",
              image: "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&w=800",
              content: [
                "Crees que eres la voz en tu cabeza. Pero eres quien la observa.",
                "Optimizas. Planificas. Analizas. Intentas apagar el fuego con más leña.",
                "Cada pensamiento es un ladrillo más en el muro de tu presencia."
              ],
              worldView: "Esta Masterclass te desplaza del centro de tu mente hacia el lugar del testigo.",
            }}
            transformation={{
              title: "El Desplazamiento",
              image: "https://images.unsplash.com/photo-1493612276216-ee3925520721?auto=format&w=800",
              imagination: "Habitar un estado donde el pensamiento no es ley, sino simplemente un fenómeno observado.",
              shift: "La claridad no requiere pensar más, requiere percibir de forma más limpia."
            }}
            clarification={{
              notThis: "No es un tutorial de bienestar. Es una inmersión ontológica.",
              perception: "Nos enfocamos en el origen de la percepción, no en la modificación de la conducta superficial.",
              filter: "Diseñado para mentes analíticas que han llegado al límite de su propio razonamiento."
            }}
            authority={{
              narrative: [
                "Aprendí que la mente es una herramienta maravillosa, pero un amo tiránico.",
                "Hablo desde el lugar donde el ruido cesa y la verdad comienza."
              ]
            }}
            finalDecision={{
              title: "¿Deseas claridad real?",
              sub: "Accede a una perspectiva que transforma tu relación con cada pensamiento que surge.",
              cta: "Acceder a Masterclass"
            }}
          />
        )}

        {currentView === 'charla' && (
          <ServiceTemplate 
            hero={{
              h1: "¿Y si el vacío que sientes no es una señal de que algo falta, sino de que algo sobra?",
              sub: "Una invitación mensual al cuestionamiento radical y la comunidad de despertar.",
              facts: ["Gratuito", "Mensual", "En Vivo", "Comunidad"],
              cta: "Registrarme Gratis"
            }}
            problem={{
              title: "El Enfoque",
              image: "https://images.unsplash.com/photo-1468413253725-0d5181091126?auto=format&w=800",
              content: [
                "Estudiar, casarse, trabajar... Alcanzas todo y aparece el vacío.",
                "¿Por qué el libreto ya hecho no nos hace felices?",
                "Seguimos metas externas esperando una satisfacción que nunca reside allí."
              ],
              worldView: "Esta charla es una primera toma de contacto con tu propia conciencia esencial.",
            }}
            transformation={{
              title: "La Apertura",
              image: "https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&w=800",
              imagination: "Un momento para dejar de huir y empezar a escuchar lo que realmente importa.",
              shift: "Solo necesitas curiosidad. La verdad no se enseña, se recuerda."
            }}
            clarification={{
              notThis: "No es un webinar de ventas. Es una conversación de despertar.",
              perception: "El objetivo es la resonancia, no la persuasión comercial.",
              filter: "Bienvenidos quienes dudan, quienes buscan y quienes ya no se conforman."
            }}
            authority={{
              narrative: [
                "Mi papel no es enseñarte, sino facilitar el espacio para que te veas a ti misma.",
                "Estamos juntas en este proceso de desaprender el mundo."
              ]
            }}
            finalDecision={{
              title: "¿Deseas iniciar tu despertar?",
              sub: "Únete a la próxima sesión en vivo y descubre las voces que no son tuyas.",
              cta: "Reservar mi Plaza"
            }}
          />
        )}

        {currentView === 'programa4w' && (
          <ServiceTemplate 
            hero={{
              h1: "La verdadera metamorfosis ocurre cuando dejas de huir de tu propia quietud y decides habitarla.",
              sub: "Un programa intensivo de 4 semanas para desmantelar al personaje y liberar la esencia.",
              facts: ["28 Días", "Digital", "Grupo Selecto", "Acompañado"],
              cta: "Iniciar el Viaje"
            }}
            problem={{
              title: "La Inercia",
              image: "https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?auto=format&w=800",
              content: [
                "Vives en piloto automático, respondiendo a demandas que aceptaste por inercia.",
                "Tu personaje actual requiere toda tu energía para ser sostenido.",
                "Te identificas con tus reacciones emocionales y tu imagen de éxito."
              ],
              worldView: "Este programa no gestiona tu vida actual; te invita a descubrir quién eres sin ella.",
            }}
            transformation={{
              title: "La Esencia",
              image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&w=800",
              imagination: "Cuatro semanas para deconstruir el 'personaje' y abrir espacio a la esencia que desea prosperar.",
              shift: "La metamorfosis es el resultado natural de dejar de resistirse a lo que uno es."
            }}
            clarification={{
              notThis: "No es un curso de autoayuda. Es una transformación estructural.",
              perception: "Buscamos un cambio en la raíz de tu identidad, no una mejora cosmética de tus hábitos.",
              filter: "Requiere compromiso absoluto con la honestidad radical. No apto para quienes buscan soluciones pasivas."
            }}
            authority={{
              narrative: [
                "Pasé del cansancio crónico a la vitalidad de la presencia real.",
                "Te guío a través de los puentes que yo misma tuve que cruzar."
              ]
            }}
            finalDecision={{
              title: "¿Lista para la transformación real?",
              sub: "Un acompañamiento diseñado para quienes han decidido que ya no hay vuelta atrás.",
              cta: "Aplicar Ahora"
            }}
          />
        )}

        {currentView === 'podcast' && <PodcastSlider />}
        {currentView === 'privacy' && (
          <div className="animate-in fade-in duration-1000 bg-[#F1F3F5] min-h-screen pt-40 px-8">
            <div className="max-w-4xl mx-auto space-y-16 pb-32">
              <span className="text-[#A5A3B2] font-bold tracking-[0.5em] text-[10px] uppercase">Legal</span>
              <h1 className="text-4xl md:text-7xl font-syne font-bold text-[#1C1C1E] tracking-tighter uppercase">Protección de Datos</h1>
              <div className="space-y-8 text-[#1C1C1E]/70 font-light leading-relaxed text-lg">
                 <p>En este espacio respetamos tu privacidad tanto como tu proceso interno.</p>
                 <p>Tus datos se utilizarán exclusivamente para gestionar tu acceso a los servicios solicitados y comunicarte novedades relevantes sobre nuestra comunidad.</p>
              </div>
              <button onClick={() => setCurrentView('home')} className="btn-liquid-glass bg-[#8FAEA3] text-white text-[11px] font-bold tracking-[0.3em] uppercase py-4 px-8 rounded-sm">Volver al Inicio</button>
            </div>
          </div>
        )}
      </main>

      <footer className="py-48 px-8 bg-[#1C1C1E] text-white">
        <div className="max-w-[1400px] mx-auto flex flex-col md:flex-row justify-between items-end gap-24">
          <div className="space-y-16 text-left w-full md:w-auto">
            <button onClick={() => setCurrentView('home')} className="font-syne text-6xl md:text-8xl font-bold tracking-tighter uppercase hover:text-[#8FAEA3] transition-colors">MAFE</button>
            <div className="flex flex-col md:flex-row gap-8">
              <button onClick={() => setCurrentView('privacy')} className="text-[11px] font-bold uppercase tracking-[0.4em] text-white/50 hover:text-[#8FAEA3]">Protección de Datos</button>
              <a href="#" className="text-[11px] font-bold uppercase tracking-[0.4em] text-white/50 hover:text-[#8FAEA3]">Instagram</a>
              <a href="#" className="text-[11px] font-bold uppercase tracking-[0.4em] text-white/50 hover:text-[#8FAEA3]">Spotify</a>
            </div>
          </div>
          <div className="text-left md:text-right space-y-8">
            <p className="text-white/60 text-xl italic font-serif-elegant max-w-md">"Mi misión es acompañar el despertar de quienes están listos para habitar su propia verdad."</p>
            <p className="text-[10px] text-white/30 uppercase tracking-[0.4em] font-bold">© 2026 MAFE • SURF YOUR VISION.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
