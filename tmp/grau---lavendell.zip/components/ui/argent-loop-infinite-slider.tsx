
import * as React from "react";

interface ProjectData {
  title: string;
  image: string;
  category: string;
  year: string;
  description: string;
  spotifyUrl?: string;
  youtubeUrl?: string;
}

const PROJECT_DATA: ProjectData[] = [
  {
    title: "El Autopiloto",
    image: "https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?q=80&w=1200&auto=format&fit=crop",
    category: "Episodio 01",
    year: "2025",
    description: "¿Por qué vivimos sin presencia?",
    spotifyUrl: "#",
    youtubeUrl: "#"
  },
  {
    title: "Incertidumbre",
    image: "https://images.unsplash.com/photo-1464618663641-bbdd760ae84a?q=80&w=1200&auto=format&fit=crop",
    category: "Episodio 02",
    year: "2025",
    description: "Amigarte con lo desconocido.",
    spotifyUrl: "#",
    youtubeUrl: "#"
  },
  {
    title: "Voz Interior",
    image: "https://images.unsplash.com/photo-1518005020250-675f0f0fd13b?q=80&w=1200&auto=format&fit=crop",
    category: "Episodio 03",
    year: "2025",
    description: "Escuchar el susurro real.",
    spotifyUrl: "#",
    youtubeUrl: "#"
  },
  {
    title: "Transiciones",
    image: "https://images.unsplash.com/photo-1502680390469-be75c86b636f?q=80&w=1200&auto=format&fit=crop",
    category: "Episodio 04",
    year: "2025",
    description: "El puente entre quién eras y quién eres.",
    spotifyUrl: "#",
    youtubeUrl: "#"
  },
  {
    title: "Libertad Raíz",
    image: "https://images.unsplash.com/photo-1439405326854-01517487c73b?q=80&w=1200&auto=format&fit=crop",
    category: "Episodio 05",
    year: "2025",
    description: "Desmontando mandatos ajenos.",
    spotifyUrl: "#",
    youtubeUrl: "#"
  },
];

const CONFIG = {
  SCROLL_SPEED: 0.6,
  LERP_FACTOR: 0.06,
  BUFFER_SIZE: 5,
  MAX_VELOCITY: 120,
  SNAP_DURATION: 600,
};

const lerp = (start: number, end: number, factor: number) =>
  start + (end - start) * factor;

const getProjectData = (index: number) => {
  const i =
    ((Math.abs(index) % PROJECT_DATA.length) + PROJECT_DATA.length) %
    PROJECT_DATA.length;
  return PROJECT_DATA[i];
};

const getProjectNumber = (index: number) => {
  return (
    ((Math.abs(index) % PROJECT_DATA.length) + PROJECT_DATA.length) %
      PROJECT_DATA.length +
    1
  )
    .toString()
    .padStart(2, "0");
};

export function PodcastSlider() {
  const [visibleRange, setVisibleRange] = React.useState({
    min: -CONFIG.BUFFER_SIZE,
    max: CONFIG.BUFFER_SIZE,
  });

  const state = React.useRef({
    currentY: 0,
    targetY: 0,
    isDragging: false,
    isSnapping: false,
    snapStart: { time: 0, y: 0, target: 0 },
    lastScrollTime: Date.now(),
    dragStart: { y: 0, scrollY: 0 },
    projectHeight: 0,
    minimapHeight: 420,
  });

  const projectsRef = React.useRef<Map<number, HTMLDivElement>>(new Map());
  const minimapRef = React.useRef<Map<number, HTMLDivElement>>(new Map());
  const infoRef = React.useRef<Map<number, HTMLDivElement>>(new Map());
  const requestRef = React.useRef<number>(null);

  const updateParallax = (
    img: HTMLImageElement | null,
    scroll: number,
    index: number,
    height: number
  ) => {
    if (!img) return;
    if (!img.dataset.parallaxCurrent) {
      img.dataset.parallaxCurrent = "0";
    }
    
    let current = parseFloat(img.dataset.parallaxCurrent);
    const target = (-scroll - index * height) * 0.15; 
    current = lerp(current, target, 0.1);
    
    if (Math.abs(current - target) > 0.01) {
        img.style.transform = `translateY(${current}px) scale(1.4)`;
        img.dataset.parallaxCurrent = current.toString();
    }
  };

  const updateSnap = () => {
    const s = state.current;
    const progress = Math.min(
      (Date.now() - s.snapStart.time) / CONFIG.SNAP_DURATION,
      1
    );
    const eased = 1 - Math.pow(1 - progress, 4);
    s.targetY =
      s.snapStart.y + (s.snapStart.target - s.snapStart.y) * eased;
    if (progress >= 1) s.isSnapping = false;
  };

  const snapToProject = () => {
    const s = state.current;
    const current = Math.round(-s.targetY / s.projectHeight);
    const target = -current * s.projectHeight;
    s.isSnapping = true;
    s.snapStart = {
      time: Date.now(),
      y: s.targetY,
      target: target,
    };
  };

  const updatePositions = () => {
    const s = state.current;
    const minimapY = (s.currentY * s.minimapHeight) / s.projectHeight;

    projectsRef.current.forEach((el, index) => {
      const y = index * s.projectHeight + s.currentY;
      el.style.transform = `translateY(${y}px)`;
      const img = el.querySelector("img");
      updateParallax(img, s.currentY, index, s.projectHeight);
    });

    minimapRef.current.forEach((el, index) => {
      const y = index * s.minimapHeight + minimapY;
      el.style.transform = `translateY(${y}px)`;
      const img = el.querySelector("img");
      if (img) {
          updateParallax(img, minimapY, index, s.minimapHeight);
      }
    });

    infoRef.current.forEach((el, index) => {
      const y = index * s.minimapHeight + minimapY;
      el.style.transform = `translateY(${y}px)`;
    });
  };

  const animate = () => {
    const s = state.current;
    const now = Date.now();

    if (!s.isSnapping && !s.isDragging && now - s.lastScrollTime > 150) {
      const snapPoint =
        -Math.round(-s.targetY / s.projectHeight) * s.projectHeight;
      if (Math.abs(s.targetY - snapPoint) > 1) snapToProject();
    }

    if (s.isSnapping) updateSnap();
    if (!s.isDragging) {
      s.currentY += (s.targetY - s.currentY) * CONFIG.LERP_FACTOR;
    }

    updatePositions();
  };
  
  const renderedRange = React.useRef({ min: -CONFIG.BUFFER_SIZE, max: CONFIG.BUFFER_SIZE });

  const animationLoop = () => {
     animate();
     
     const s = state.current;
     const currentIndex = Math.round(-s.targetY / s.projectHeight);
     const min = currentIndex - CONFIG.BUFFER_SIZE;
     const max = currentIndex + CONFIG.BUFFER_SIZE;

     if (min !== renderedRange.current.min || max !== renderedRange.current.max) {
         renderedRange.current = { min, max };
         setVisibleRange({ min, max });
     }

     requestRef.current = requestAnimationFrame(animationLoop);
  };

  React.useEffect(() => {
    state.current.projectHeight = window.innerHeight;
    
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const s = state.current;
      s.isSnapping = false;
      s.lastScrollTime = Date.now();
      const delta = Math.max(
        Math.min(e.deltaY * CONFIG.SCROLL_SPEED, CONFIG.MAX_VELOCITY),
        -CONFIG.MAX_VELOCITY
      );
      s.targetY -= delta;
    };

    // Fixed: Changed from TouchStart to TouchEvent to resolve missing type error
    const onTouchStart = (e: TouchEvent) => {
        const s = state.current;
        s.isDragging = true;
        s.isSnapping = false;
        s.dragStart = { y: e.touches[0].clientY, scrollY: s.targetY };
        s.lastScrollTime = Date.now();
    }

    // Fixed: Changed from TouchMove to TouchEvent to resolve missing type error
    const onTouchMove = (e: TouchEvent) => {
        const s = state.current;
        if (!s.isDragging) return;
        s.targetY =
            s.dragStart.scrollY +
            (e.touches[0].clientY - s.dragStart.y) * 1.5;
        s.lastScrollTime = Date.now();
    }

    const onTouchEnd = () => {
        state.current.isDragging = false;
    }

    const onResize = () => {
        state.current.projectHeight = window.innerHeight;
    }

    window.addEventListener("wheel", onWheel, { passive: false });
    window.addEventListener("touchstart", onTouchStart);
    window.addEventListener("touchmove", onTouchMove);
    window.addEventListener("touchend", onTouchEnd);
    window.addEventListener("resize", onResize);
    
    onResize();
    requestRef.current = requestAnimationFrame(animationLoop);

    return () => {
      window.removeEventListener("wheel", onWheel);
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("touchend", onTouchEnd);
      window.removeEventListener("resize", onResize);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const indices = [];
  for (let i = visibleRange.min; i <= visibleRange.max; i++) {
    indices.push(i);
  }

  return (
    <div className="parallax-container">
      {/* Background Layer (Big Images) */}
      <ul className="project-list">
        {indices.map((i) => {
          const data = getProjectData(i);
          return (
            <div
              key={i}
              className="project"
              ref={(el) => {
                if (el) projectsRef.current.set(i, el);
                else projectsRef.current.delete(i);
              }}
            >
              <img src={data.image} alt={data.title} className="opacity-10 grayscale" />
            </div>
          );
        })}
      </ul>

      {/* Central Interactive Card (Minimap) */}
      <div className="minimap border-[#1C1C1E]/5">
        <div className="minimap-wrapper">
          <div className="minimap-img-preview">
            {indices.map((i) => {
              const data = getProjectData(i);
              return (
                <div
                  key={i}
                  className="minimap-img-item"
                  ref={(el) => {
                    if (el) minimapRef.current.set(i, el);
                    else minimapRef.current.delete(i);
                  }}
                >
                  <img src={data.image} alt={data.title} className="opacity-90 contrast-110" />
                </div>
              );
            })}
          </div>
          <div className="minimap-info-list">
            {indices.map((i) => {
              const data = getProjectData(i);
              const num = getProjectNumber(i);
              return (
                <div
                  key={i}
                  className="minimap-item-info"
                  ref={(el) => {
                    if (el) infoRef.current.set(i, el);
                    else infoRef.current.delete(i);
                  }}
                >
                  <div className="info-num text-[#1C1C1E]/40">{num}</div>
                  <div className="info-title text-[#1C1C1E]">{data.title}</div>
                  <div className="info-cat text-[#8FAEA3]">{data.category}</div>
                  <div className="info-year text-[#A5A3B2]/80">{data.year}</div>
                  <div className="info-desc text-[#1C1C1E]">{data.description}</div>
                  <div className="info-links">
                    <a href={data.spotifyUrl} className="social-link" title="Spotify">
                        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.503 17.303c-.214.351-.671.463-1.021.249-2.812-1.718-6.353-2.106-10.518-1.156-.401.092-.802-.158-.894-.559-.092-.401.158-.802.559-.894 4.562-1.042 8.473-.591 11.625 1.332.35.214.462.67.249 1.028zm1.468-3.26c-.27.439-.844.582-1.283.312-3.221-1.979-8.131-2.553-11.938-1.398-.495.15-1.018-.129-1.168-.624-.15-.495.129-1.018.624-1.168 4.352-1.321 9.771-.678 13.451 1.583.439.27.583.844.314 1.295zm.126-3.411c-3.864-2.294-10.244-2.506-13.978-1.371-.593.18-1.222-.154-1.402-.747-.18-.593.154-1.222.747-1.402 4.298-1.306 11.339-1.053 15.79 1.589.533.317.708 1.005.392 1.538-.316.533-1.005.708-1.549.393z"/></svg>
                    </a>
                    <a href={data.youtubeUrl} className="social-link" title="YouTube">
                        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Brand Header Overlay */}
      <div className="absolute top-12 left-12 z-50 pointer-events-none">
        <span className="font-syne text-[#8FAEA3] text-xs tracking-[0.6em] font-bold uppercase opacity-80">MaFe Podcast // El Despertar</span>
      </div>
      
      {/* Footer Hint */}
      <div className="absolute bottom-12 right-12 z-50 pointer-events-none">
        <div className="flex flex-col items-end gap-2">
            <span className="text-[#1C1C1E]/30 text-[9px] tracking-[0.4em] uppercase font-bold">Inmersión Infinita</span>
            <div className="h-px w-24 bg-[#1C1C1E]/10"></div>
        </div>
      </div>
    </div>
  );
}
