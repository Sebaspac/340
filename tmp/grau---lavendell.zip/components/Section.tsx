
import React from 'react';
import { SectionProps } from '../types';

export const Section: React.FC<SectionProps> = ({ 
  title, 
  children, 
  imageSrc, 
  imageAlt, 
  imageRight = false,
  bgImage,
  overlayOpacity = "bg-[#F1F3F5]/85"
}) => {
  return (
    <section className="relative min-h-screen flex items-center py-32 overflow-hidden bg-[#F1F3F5]">
      {/* Parallax Background Layer */}
      {bgImage && (
        <div 
          className="absolute inset-0 z-0 pointer-events-none"
          style={{
            backgroundImage: `url(${bgImage})`,
            backgroundAttachment: 'fixed',
            backgroundPosition: 'center',
            backgroundSize: 'cover',
          }}
        >
          {/* Overlay configurable para legibilidad */}
          <div className={`absolute inset-0 ${overlayOpacity} backdrop-blur-[1px]`}></div>
        </div>
      )}

      <div className="relative z-10 max-w-[1140px] mx-auto px-8 w-full">
        <div className={`flex flex-col ${imageRight ? 'md:flex-row-reverse' : 'md:flex-row'} gap-24 items-center`}>
          <div className="w-full md:w-1/2 space-y-12">
            {title && (
              <h2 className="text-4xl md:text-6xl font-syne font-bold text-[#1C1C1E] tracking-tighter uppercase leading-none">
                {title}
              </h2>
            )}
            <div className="space-y-8">
              {children}
            </div>
          </div>
          <div className="w-full md:w-1/2">
            <div className="relative aspect-[4/5] overflow-hidden group rounded-sm shadow-xl">
              <img 
                src={imageSrc} 
                alt={imageAlt} 
                className="w-full h-full object-cover grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000 scale-105 group-hover:scale-100" 
              />
              <div className="absolute inset-0 border border-[#1C1C1E]/10 group-hover:border-[#8FAEA3]/50 transition-colors pointer-events-none"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
