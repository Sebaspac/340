
import React, { useState, useEffect, useCallback } from 'react';

const testimonials = [
  {
    name: "Elena R.",
    role: "WORKSHOP VISIÓN",
    text: "Romper el 'libreto predefinido' fue la decisión más difícil y gratificante de mi vida. MaFe me dio la estructura y seguridad interior para no sentirme sola en el vacío.",
    image: "https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=150&h=150&q=80"
  },
  {
    name: "Sofia M.",
    role: "CHARLA MENSUAL",
    text: "La charla gratuita fue mi primera toma de conciencia. Por fin entendí que mi saturación mental no era un fallo personal, sino una brújula avisándome que estaba perdida.",
    image: "https://images.unsplash.com/photo-1528150177508-7cc0c36cda5c?auto=format&fit=crop&w=150&h=150&q=80"
  },
  {
    name: "Carla P.",
    role: "GROWTH MINDSET",
    text: "Sanar y soltar mandatos externos requiere resiliencia. El taller de mentalidad me ha dado las herramientas para sostener mi nueva visión sin sabotearme.",
    image: "https://images.unsplash.com/photo-1518005020250-675f0f0fd13b?auto=format&fit=crop&w=150&h=150&q=80"
  }
];

export const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  }, []);

  useEffect(() => {
    const interval = setInterval(next, 8000);
    return () => clearInterval(interval);
  }, [next]);

  return (
    <section className="py-40 bg-[#8FAEA3]/5 px-6 border-b border-[#1C1C1E]/5">
      <div className="max-w-[1140px] mx-auto">
        <div className="flex flex-col md:flex-row gap-24 items-center">
            <div className="w-full md:w-1/3">
                 <h2 className="text-5xl font-syne font-bold text-[#1C1C1E] tracking-tighter uppercase leading-none mb-8">Testimonios</h2>
                 <p className="text-[#1C1C1E]/50 font-serif-elegant italic text-xl">Voces de quienes ya iniciaron su despertar.</p>
                 <div className="flex gap-4 mt-12">
                   {testimonials.map((_, idx) => (
                      <button 
                        key={idx}
                        onClick={() => setCurrentIndex(idx)}
                        className={`h-px transition-all duration-500 ${currentIndex === idx ? 'w-16 bg-[#A5A3B2]' : 'w-8 bg-[#1C1C1E]/10'}`}
                        aria-label={`Testimonio ${idx + 1}`}
                      />
                   ))}
                 </div>
            </div>
            
            <div className="w-full md:w-2/3 bg-white border border-[#1C1C1E]/5 p-12 md:p-20 relative shadow-lg rounded-sm">
               <span className="absolute top-12 left-12 text-[#A5A3B2]/10 font-serif-elegant text-8xl">"</span>
               <div className="relative z-10">
                 <p className="text-3xl md:text-4xl font-serif-elegant italic text-[#1C1C1E] leading-snug mb-12">
                   {testimonials[currentIndex].text}
                 </p>
                 <div className="flex items-center gap-6">
                    <img src={testimonials[currentIndex].image} className="w-14 h-14 rounded-full grayscale object-cover border border-[#1C1C1E]/10" alt={testimonials[currentIndex].name} />
                    <div>
                       <p className="text-[#1C1C1E] font-bold tracking-[0.2em] text-[11px] uppercase">{testimonials[currentIndex].name}</p>
                       <p className="text-[#A5A3B2] text-[10px] tracking-[0.2em] uppercase font-bold mt-1 opacity-80">{testimonials[currentIndex].role}</p>
                    </div>
                 </div>
               </div>
            </div>
        </div>
      </div>
    </section>
  );
};
