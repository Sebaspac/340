
import React, { useState } from 'react';
import { View } from '../types';

interface NavigationProps {
  currentView: View;
  setView: (view: View) => void;
}

const serviceLabels: Record<string, string> = {
  workshops: 'Talleres',
  masterclasses: 'Master Classes',
  charla: 'Charla Gratuita',
  programa4w: 'Programa 4 Semanas'
};

export const Navigation: React.FC<NavigationProps> = ({ currentView, setView }) => {
  const [activeDropdown, setActiveDropdown] = useState<'services' | null>(null);

  const handleLink = (view: View) => {
    setView(view);
    setActiveDropdown(null);
  };

  const isServiceActive = ['workshops', 'masterclasses', 'charla', 'programa4w'].includes(currentView);

  return (
    <nav className="fixed top-0 left-0 w-full z-[100] bg-[#F1F3F5]/90 backdrop-blur-xl border-b border-[#1C1C1E]/5">
      <div className="max-w-[1400px] mx-auto px-8 h-24 flex justify-between items-center">
        {/* Logo */}
        <button onClick={() => setView('home')} className="flex items-center group">
          <span className={`font-syne font-bold tracking-[0.5em] text-xl uppercase transition-colors group-hover:text-[#8FAEA3] ${currentView === 'home' ? 'text-[#8FAEA3]' : 'text-[#1C1C1E]'}`}>MaFe</span>
        </button>

        {/* Center Navigation Links */}
        <div className="hidden md:flex items-center space-x-6 text-[11px] font-bold tracking-[0.3em] uppercase">
          <div 
            className="relative py-8 cursor-pointer group"
            onMouseEnter={() => setActiveDropdown('services')}
            onMouseLeave={() => setActiveDropdown(null)}
          >
            <span className={`transition-colors flex items-center hover:text-[#8FAEA3] ${isServiceActive ? 'text-[#8FAEA3]' : 'text-[#1C1C1E]/60'}`}>
              Servicios
            </span>
            {/* Dropdown */}
            <div className={`absolute top-full left-1/2 -translate-x-1/2 w-64 bg-[#F1F3F5] border border-[#1C1C1E]/10 p-2 transition-all duration-300 shadow-2xl ${activeDropdown === 'services' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2 pointer-events-none'}`}>
              <div className="flex flex-col">
                {['workshops', 'masterclasses', 'charla', 'programa4w'].map((v) => (
                   <button 
                    key={v}
                    onClick={() => handleLink(v as View)} 
                    className={`text-center px-4 py-3 hover:bg-[#8FAEA3]/10 hover:text-[#8FAEA3] transition-all uppercase text-[9px] tracking-[0.2em] ${currentView === v ? 'text-[#8FAEA3]' : 'text-[#1C1C1E]/70'}`}
                  >
                    {serviceLabels[v]}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <span className="text-[#1C1C1E]/20 font-light text-[8px]">•</span>

          <button 
            onClick={() => handleLink('podcast')} 
            className={`transition-colors hover:text-[#8FAEA3] ${currentView === 'podcast' ? 'text-[#8FAEA3]' : 'text-[#1C1C1E]/60'}`}
          >
            Podcast
          </button>
        </div>

        {/* Reservar Button */}
        <button 
          onClick={() => handleLink('programa4w')} 
          className="border border-[#1C1C1E]/15 bg-[#8FAEA3]/20 hover:bg-[#8FAEA3]/40 text-[#1C1C1E] px-10 py-4 text-[10px] font-bold tracking-[0.4em] uppercase transition-all rounded-sm"
        >
          Reservar
        </button>
      </div>
    </nav>
  );
};
