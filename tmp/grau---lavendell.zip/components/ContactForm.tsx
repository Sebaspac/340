
import React from 'react';

export const ContactForm: React.FC = () => {
  return (
    <div className="bg-white p-12 md:p-16 border border-[#1C1C1E]/5 shadow-xl rounded-sm">
      <h3 className="text-3xl font-syne font-bold mb-12 text-[#1C1C1E] uppercase tracking-tighter">Hablemos</h3>
      <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] font-bold tracking-[0.2em] text-[#1C1C1E]/50 uppercase">Nombre</label>
            <input type="text" className="w-full bg-[#F1F3F5] border-b border-[#1C1C1E]/10 py-4 px-4 focus:border-[#8FAEA3] focus:outline-none transition-all text-[#1C1C1E] font-light" />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-bold tracking-[0.2em] text-[#1C1C1E]/50 uppercase">Email</label>
            <input type="email" className="w-full bg-[#F1F3F5] border-b border-[#1C1C1E]/10 py-4 px-4 focus:border-[#8FAEA3] focus:outline-none transition-all text-[#1C1C1E] font-light" />
          </div>
        </div>
        <div className="space-y-2">
            <label className="text-[10px] font-bold tracking-[0.2em] text-[#1C1C1E]/50 uppercase">Mensaje</label>
            <textarea rows={4} className="w-full bg-[#F1F3F5] border-b border-[#1C1C1E]/10 py-4 px-4 focus:border-[#8FAEA3] focus:outline-none transition-all text-[#1C1C1E] font-light"></textarea>
        </div>
        <button className="btn-liquid-glass w-full bg-[#8FAEA3] text-white font-bold py-6 rounded-sm hover:bg-[#1C1C1E] transition-all tracking-[0.3em] uppercase text-xs">
          Enviar
        </button>
      </form>
    </div>
  );
};
