
import React from 'react';
import { CalendarIcon, ClockIcon, TagIcon } from './Icons';

export const MetaList: React.FC = () => {
  return (
    <div className="space-y-3 mb-8">
      <div className="flex items-center text-gray-700 font-medium">
        <span className="mr-3 text-violet-800"><CalendarIcon /></span>
        <span>Datum: 15.02.26, um 17:45 Uhr</span>
      </div>
      <div className="flex items-center text-gray-700 font-medium">
        <span className="mr-3 text-violet-800"><ClockIcon /></span>
        <span>Dauer: 60 Minuten</span>
      </div>
      <div className="flex items-center text-gray-700 font-medium">
        <span className="mr-3 text-violet-800"><TagIcon /></span>
        <span>Preis: 29€ netto</span>
      </div>
    </div>
  );
};
